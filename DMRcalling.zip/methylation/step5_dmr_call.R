##bsseq##
##R3.1.0##
##dmr calling R script##
## ----style-knitr, eval=TRUE, echo=FALSE, results="asis"------------------
BiocStyle::latex()

## ----load,warnings=FALSE,messages=FALSE----------------------------------
library(bsseq)

## ----showData------------------------------------------------------------
data(covfile)
covfile <- updateObject(covfile)
covfile
pData(covfile)

## ----smooth,eval=FALSE---------------------------------------------------
## covfile.smoothed <- BSmooth(covfile, mc.cores = 6, verbose = TRUE)

## ----showDataFit---------------------------------------------------------
data(covfile.smoothed)
covfile.smoothed <- updateObject(covfile.smoothed)
covfile.smoothed

## ----cpgNumbers----------------------------------------------------------
## The average coverage of CpGs on the two chromosomes
round(colMeans(getCoverage(covfile)), 1)
## Number of CpGs
length(covfile.smoothed)
## Number of CpGs which are covered by at least 5 read in all 6 samples
sum(rowSums(getCoverage(covfile.smoothed) >= 5) == 6)

## ----poisson-------------------------------------------------------------
logp <- ppois(0, lambda = 4, lower.tail = FALSE, log.p = TRUE)
round(1 - exp(6 * logp), 3)

## ----smoothSplit,eval=FALSE----------------------------------------------
## ## Split datag
## BS1 <- covfile[, 1]
## save(BS1, file = "BS1.rda")
## BS2 <- covfile[, 2]
## save(BS1, file = "BS1.rda")
## ## done splitting
## 
## ## Do the following on each node
## 
## ## node 1
## load("BS1.rda")
## BS1.smoothed <- BSmooth(BS1)
## save(BS1.smoothed)
## save(BS1.smoothed, file = "BS1.smoothed.rda")
## ## done node 1
## 
## ## node 2
## load("BS2.rda")
## BS2.smoothed <- BSmooth(BS2)
## save(BS2.smoothed, file = "BS2.smoothed.rda")
## ## done node 2
## 
## ## join; in a new R session
## load("BS1.smoothed.rda")
## load("BS2.smoothed.rda")
## BS.smoothed <- combine(BS1.smoothed, BS2.smoothed)

## ----keepLoci------------------------------------------------------------
BS.cov <- getCoverage(covfile.smoothed)
keepLoci.ex <- which(rowSums(BS.cov[, covfile.smoothed$Type == "G"] >= 5) >= 3 &
                     rowSums(BS.cov[, covfile.smoothed$Type == "H"] >= 5) >= 3)
length(keepLoci.ex)
covfile.smoothed <- covfile.smoothed[keepLoci.ex,]

## ----BSmooth.tstat-------------------------------------------------------
covfile.smoothed.tstat <- BSmooth.tstat(covfile.smoothed, 
                                    group1 = c("G1", "G2", "G3"),
                                    group2 = c("H1", "H2", "H3"),
                                    estimate.var = "paired",
                                    local.correct = TRUE,
                                    verbose = TRUE)
covfile.smoothed.tstat

## ----plotTstat,fig.width=4,fig.height=4----------------------------------
plot(covfile.smoothed.tstat)

## ----dmrs----------------------------------------------------------------
dmrs0 <- dmrFinder(covfile.smoothed.tstat, cutoff = c(-5, 5))
dmrs <- subset(dmrs0, n >= 6 & abs(meanDiff) >= 0.2)

## ----sessionInfo,results="asis",eval=TRUE,echo=FALSE---------------------
toLatex(sessionInfo())

